make codegen
make build
yarn db:generate
make migrate