import type {Result} from './support'

export type AccountId32 = Uint8Array
