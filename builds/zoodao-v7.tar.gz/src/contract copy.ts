export const CHAIN_NODE = 'wss://moonbeam.api.onfinality.io/public-ws' //'wss://moonbeam.public.blastapi.io'

export const FAUCET_MOONBEAM = '0xEbB0B2ec33B267582b1BE4C87bB88CEC8ce99263'.toLowerCase()

export const BATTLE_STAKER_MOONBEAM = '0x03099672545f88245BecDe8529A5846Fb20738b2'.toLowerCase()
export const BATTLE_VOTER_MOONBEAM = '0x7318138C7109B31A920CFd06Cb7bd615A643E722'.toLowerCase()
export const BATTLE_ARENA_MOONBEAM = '0x667ba8D366aFA5028Db3a22AAf9aC5ea3FD48C14'.toLowerCase()

export const VE_MODEL_MOONBEAM = '0xcc3f70f3d83090Cb1650F879ac38839C016A3b6a'.toLowerCase()

export const X_ZOO_MOONBEAM = '0x95f543721b3d1A799FDC4902b4d325Bf79cEd76F'.toLowerCase()

export const JACKPOT_A_MOONBEAM = '0x1Fd9964365E0AfF0115f15f05A65370f94bd17cc'.toLowerCase()
export const JACKPOT_B_MOONBEAM = '0x0795D955574ADc612551C3CfC91c3a0Ba1A19bB5'.toLowerCase()

export const WGLMR_MOONBEAM = '0xacc15dc74880c9944775448304b263d191c6077f'.toLowerCase()
export const WELL_MOONBEAM = '0x511ab53f793683763e5a8829738301368a2411e3'.toLowerCase()
